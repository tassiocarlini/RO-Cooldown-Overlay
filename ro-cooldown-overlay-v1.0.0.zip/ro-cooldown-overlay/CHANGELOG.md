# Mudanças

## v1.0.0 — primeira versão pública
- Overlay de recarga das skills perto do centro da tela, sem receber cliques.
- Detecção pela tela: o programa compara cada ícone da barra de atalhos com a imagem dele "pronto".
- Recarga manual, aprendida sozinha ou vinda do banco de skills (classes de 4ª, em português).
- Busca automática dos ícones quando a barra muda de lugar; não conta delay falso quando o ícone some.
- Overlay preso à janela do Ragnarok (acompanha a janela e some quando o jogo é minimizado).
- Perfis por personagem, mover e redimensionar, direção horizontal/vertical.
- Integração opcional com a API da Divine Pride (recarga LATAM, ícones e "+ Skill pelo nome").
- Versão `.exe` para Windows: não precisa instalar Python. Configurações ficam em `%APPDATA%\RO Cooldown Overlay`.
