@echo off
REM Roda o programa direto pelo Python (para quem tem Python instalado).
REM Quem nao tem Python: baixe o .zip pronto na pagina "Releases" do GitHub.
cd /d "%~dp0"
python -c "import mss, PIL, numpy, cv2" 2>nul || python -m pip install -r requirements.txt
start "" pythonw "%~dp0ro_cooldown_overlay.py"
