# -*- coding: utf-8 -*-
"""
RO Cooldown Overlay v3 — estilo WeakAuras para Ragnarok Online LATAM.

Abre um painel onde você:
  - cria PERFIS (ex.: um por personagem), que ficam salvos;
  - marca os ícones das skills na barra de atalhos;
  - digita a recarga de cada skill (ou deixa vazio para o programa aprender);
  - move e redimensiona os ícones do overlay.

Como detecta o delay:
  Olha a tela como um print/OBS faria e compara cada ícone da barra de
  atalhos com a imagem dele "pronto". Não lê memória, não injeta nada no
  client, não escuta nem envia teclas.

Requisitos: Windows 10/11 e Python 3.10+
    pip install mss pillow numpy opencv-python

Uso: dê dois cliques em iniciar.bat (ou rode: python ro_cooldown_overlay.py)
"""

import copy
import ctypes
import json
import math
import os
import re
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import shutil
import sys
import time
import tkinter as tk
import traceback
from ctypes import wintypes
from pathlib import Path
from tkinter import messagebox, simpledialog, ttk

if sys.platform != "win32":
    sys.exit("Este overlay só funciona no Windows.")

import queue
import threading

import mss
from PIL import Image, ImageChops, ImageEnhance, ImageStat, ImageTk

try:                        # para achar os ícones na tela sozinho
    import numpy as np
except ImportError:
    np = None
try:
    import cv2
except ImportError:
    cv2 = None

LIMIAR_PERDIDO = 0.5        # semelhança abaixo disso: o ícone não está mais ali
LIMIAR_ACHADO = 0.85        # semelhança mínima para aceitar um ícone encontrado


VERSAO = "1.0.0"
NOME_APP = "RO Cooldown Overlay"

if getattr(sys, "frozen", False):
    # Versão .exe: seus dados ficam em %APPDATA%, assim atualizar o programa não apaga nada
    PASTA = Path(os.environ.get("APPDATA") or Path.home()) / NOME_APP
    PASTA_RECURSOS = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
else:
    PASTA = Path(__file__).resolve().parent
    PASTA_RECURSOS = PASTA
PASTA.mkdir(parents=True, exist_ok=True)

PASTA_PERFIS = PASTA / "perfis"
ARQ_APP = PASTA / "app.json"
ARQ_BANCO = (PASTA / "banco_skills.json" if (PASTA / "banco_skills.json").exists()
             else PASTA_RECURSOS / "banco_skills.json")   # nomes e recargas padrão
ARQ_MEUS = PASTA / "meus_tempos.json"            # recargas que você corrigiu
TODAS = "Todas as classes"
PASTA_DP = PASTA / "cache_divinepride"           # respostas e ícones da Divine Pride
DP_URL = "https://www.divine-pride.net/api/database/Skill/{id}"
LIMIAR_ACHADO_DP = 0.75     # ícone da Divine Pride x ícone na tela (podem diferir um pouco)
ESCALAS_DP = (1.0, 1.25, 1.5, 2.0)
ARQ_ANTIGO = PASTA / "ro_cd_config.json"          # config da versão anterior
PASTA_ICONES_ANTIGA = PASTA / "ro_cd_icones"

COR_TRANSPARENTE = "#010101"
BARRA_H = 5

PERFIL_PADRAO = {
    "titulo_janela_jogo": "Ragnarok",
    "classe": TODAS,
    "origem_calibracao": None,         # posição do jogo quando os ícones foram marcados
    "skills": [],
    "layout": {
        "x": None, "y": None,          # None = centralizado
        "tamanho": 52,
        "espaco": 8,
        "orientacao": "horizontal",
        "esconder_quando_pronto": False,
        "esconder_sem_foco": False,
        "aviso_vermelho_s": 3.0,
        "origem": None,                # posição do jogo quando o overlay foi posicionado
    },
    "deteccao": {
        "limiar_delay": 0.10,
        "limiar_pronto": 0.03,
        "frames_entrar": 1,
        "frames_confirmar": 2,
        "min_mostrar": 0.6,
        "fps": 30,
    },
    "versao": 4,
}

JANELA_GRUPO = 0.15   # s: ícones que escurecem juntos dentro disso = delay global

user32 = ctypes.windll.user32
GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_NOACTIVATE = 0x08000000
WDA_EXCLUDEFROMCAPTURE = 0x11


# =============================================================== utilidades

def dpi_aware():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass


def nova_captura():
    """mss.MSS nas versões novas, mss.mss nas antigas."""
    return (getattr(mss, "MSS", None) or mss.mss)()


GA_ROOT = 2
HWND = wintypes.HWND


def _sig(fn, res, *args):
    fn.restype = res
    fn.argtypes = list(args)


_sig(user32.GetParent, HWND, HWND)
_sig(user32.GetWindowLongW, ctypes.c_long, HWND, ctypes.c_int)
_sig(user32.SetWindowLongW, ctypes.c_long, HWND, ctypes.c_int, ctypes.c_long)
_sig(user32.GetForegroundWindow, HWND)
_sig(user32.GetWindowTextLengthW, ctypes.c_int, HWND)
_sig(user32.GetWindowTextW, ctypes.c_int, HWND, wintypes.LPWSTR, ctypes.c_int)
_sig(user32.GetClassNameW, ctypes.c_int, HWND, wintypes.LPWSTR, ctypes.c_int)
_sig(user32.IsWindow, wintypes.BOOL, HWND)
_sig(user32.IsWindowVisible, wintypes.BOOL, HWND)
_sig(user32.IsIconic, wintypes.BOOL, HWND)
_sig(user32.GetClientRect, wintypes.BOOL, HWND, ctypes.POINTER(wintypes.RECT))
_sig(user32.ClientToScreen, wintypes.BOOL, HWND, ctypes.POINTER(wintypes.POINT))
_sig(user32.WindowFromPoint, HWND, wintypes.POINT)
_sig(user32.GetAncestor, HWND, HWND, ctypes.c_uint)
_sig(user32.SetWindowDisplayAffinity, wintypes.BOOL, HWND, wintypes.DWORD)
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, HWND, wintypes.LPARAM)
_sig(user32.EnumWindows, wintypes.BOOL, EnumWindowsProc, wintypes.LPARAM)

# Janelas que podem ter "Ragnarok" no título mas não são o jogo
# (navegadores, Discord, Explorer, terminal, este próprio programa)
CLASSES_IGNORADAS = ("Chrome_WidgetWin", "MozillaWindowClass", "TkTopLevel", "TkChild",
                     "CabinetWClass", "ConsoleWindowClass", "CASCADIA_HOSTING_WINDOW_CLASS",
                     "ApplicationFrameWindow")


def hwnd_de(janela):
    return user32.GetParent(janela.winfo_id())


def mudar_estilo(hwnd, ligar=0, desligar=0):
    estilo = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, (estilo | ligar) & ~desligar)


def texto_janela(h):
    n = user32.GetWindowTextLengthW(h)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(h, buf, n + 1)
    return buf.value


def classe_janela(h):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(h, buf, 256)
    return buf.value


def eh_jogo(h, titulo):
    if not h or not user32.IsWindow(h) or not user32.IsWindowVisible(h):
        return False
    if titulo.lower() not in texto_janela(h).lower():
        return False
    cls = classe_janela(h)
    return not any(cls.startswith(c) for c in CLASSES_IGNORADAS)


class Jogo:
    """Acha e acompanha a janela do Ragnarok (só lê título/posição da janela)."""

    def __init__(self):
        self.hwnd = None
        self._ult_busca = -99.0

    def localizar(self, titulo, agora):
        fg = user32.GetForegroundWindow()
        if fg and fg != self.hwnd and eh_jogo(fg, titulo):
            self.hwnd = fg               # o jogo em foco tem prioridade (multi-client)
            return
        if self.hwnd and agora - self._ult_busca < 0.5:
            return
        self._ult_busca = agora
        if self.hwnd and eh_jogo(self.hwnd, titulo):
            return
        achados = []

        def cb(h, _lp):
            if eh_jogo(h, titulo):
                achados.append(h)
                return False
            return True

        user32.EnumWindows(EnumWindowsProc(cb), 0)
        self.hwnd = achados[0] if achados else None

    def geometria(self):
        """(x, y, largura, altura) da área do jogo na tela, ou None."""
        h = self.hwnd
        if not h or not user32.IsWindow(h) or user32.IsIconic(h):
            return None
        r = wintypes.RECT()
        p = wintypes.POINT(0, 0)
        if not user32.GetClientRect(h, ctypes.byref(r)) or not user32.ClientToScreen(h, ctypes.byref(p)):
            return None
        if r.right <= 0 or r.bottom <= 0:
            return None
        return (p.x, p.y, r.right, r.bottom)

    def em_foco(self):
        return bool(self.hwnd) and user32.GetForegroundWindow() == self.hwnd


def janela_no_ponto(x, y):
    h = user32.WindowFromPoint(wintypes.POINT(int(x), int(y)))
    return user32.GetAncestor(h, GA_ROOT) if h else None


def miolo(img):
    """Ignora 15% de cada borda (moldura do slot, número da tecla etc.)."""
    w, h = img.size
    mx, my = max(1, int(w * 0.15)), max(1, int(h * 0.15))
    if w - 2 * mx < 2 or h - 2 * my < 2:
        return img
    return img.crop((mx, my, w - mx, h - my))


def diferenca(a, b):
    st = ImageStat.Stat(ImageChops.difference(a, b))
    return sum(st.mean) / (len(st.mean) * 255.0)


ARQ_LOG = PASTA / "log.txt"
_ult_log = {}


def registrar(msg, chave_rep=None, intervalo=10.0):
    """Escreve em log.txt (com limite de repetição para erros que se repetem a cada frame)."""
    agora = time.monotonic()
    if chave_rep is not None:
        if agora - _ult_log.get(chave_rep, -1e9) < intervalo:
            return
        _ult_log[chave_rep] = agora
    try:
        if ARQ_LOG.exists() and ARQ_LOG.stat().st_size > 500_000:
            ARQ_LOG.unlink()
        with open(ARQ_LOG, "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + msg.rstrip() + "\n")
    except Exception:
        pass


def cinza(img):
    return np.asarray(img.convert("L"), dtype=np.float32)


def _ncc(a, b):
    a = a - a.mean()
    b = b - b.mean()
    va, vb = float((a * a).sum()), float((b * b).sum())
    liso = 1e-3 * a.size
    if vb < liso:                       # pedaço liso no ícone original
        return 1.0 if va < liso else 0.0
    if va < liso:
        return 0.0
    return float((a * b).sum() / math.sqrt(va * vb))


def semelhanca(a, b, n=3):
    """0 a 1: o ícone continua sendo o mesmo? Não muda se ele escurecer, ficar cinza
    ou tiver a varredura do delay; cai para ~0 se for outro ícone ou slot vazio."""
    if a.shape != b.shape:
        return 0.0
    h, w = b.shape
    vals = [_ncc(a[i * h // n:(i + 1) * h // n, j * w // n:(j + 1) * w // n],
                 b[i * h // n:(i + 1) * h // n, j * w // n:(j + 1) * w // n])
            for i in range(n) for j in range(n)]
    return float(np.median(vals))


def sem_cor_chave(img):
    return img.point(lambda v: max(v, 2))


def texto_contorno(canvas, x, y, texto, fonte, cor):
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)):
        canvas.create_text(x + dx, y + dy, text=texto, font=fonte, fill="#000000")
    canvas.create_text(x, y, text=texto, font=fonte, fill=cor)


def ler_tempo(txt):
    """'12' / '4,5' / '1:30' -> segundos. Vazio -> None (aprender). Retorna (valor, valido)."""
    t = txt.strip().replace(",", ".")
    if not t:
        return None, True
    try:
        if ":" in t:
            m, s = t.split(":", 1)
            v = int(m) * 60 + float(s)
        else:
            v = float(t)
    except ValueError:
        return None, False
    return (v, True) if v > 0 else (None, False)


def fmt_tempo(v):
    return "" if v is None else f"{v:g}"


def fmt_aprendido(sk):
    if sk.get("cd"):
        return "usa manual"
    v = sk.get("aprendido")
    return "—" if v is None else f"{v:.1f}s"


def mesclar(padrao, dados):
    out = {}
    for k, v in padrao.items():
        if isinstance(v, dict):
            sub = dados.get(k) if isinstance(dados.get(k), dict) else {}
            out[k] = mesclar(v, sub)
        else:
            out[k] = copy.deepcopy(dados.get(k, v))
    for k, v in dados.items():
        out.setdefault(k, v)
    return out


def ler_json(arq, padrao):
    try:
        return {**padrao, **json.loads(arq.read_text(encoding="utf-8"))}
    except Exception:
        return dict(padrao)


def gravar_json(arq, dados):
    arq.write_text(json.dumps(dados, indent=2, ensure_ascii=False), encoding="utf-8")


# =============================================================== banco de skills

def chave(txt):
    """Normaliza para busca: sem acento, minúsculo."""
    t = unicodedata.normalize("NFKD", txt or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


class Banco:
    def __init__(self):
        self.itens = {}
        self.classes = []
        self.fonte = ""
        try:
            self.meus = json.loads(ARQ_MEUS.read_text(encoding="utf-8"))
        except Exception:
            self.meus = {}
        try:
            dados = json.loads(ARQ_BANCO.read_text(encoding="utf-8"))
        except Exception:
            dados = {}
        self.fonte = dados.get("fonte", "")
        for classe, lista in dados.get("classes", {}).items():
            self.classes.append(classe)
            for x in lista:
                k = chave(x.get("nome"))
                if not k:
                    continue
                it = self.itens.setdefault(k, {"nome": x["nome"], "cd": None, "classes": [],
                                               "id": x.get("id")})
                if classe not in it["classes"]:
                    it["classes"].append(classe)
                if it["cd"] is None and x.get("cd"):
                    it["cd"] = x["cd"]
        self.ok = bool(self.itens)
        self.dp = None

    def id_de(self, nome):
        it = self.itens.get(chave(nome))
        return it.get("id") if it else None

    def recarga_padrao(self, nome):
        it = self.itens.get(chave(nome))
        return it["cd"] if it else None

    def recarga(self, nome):
        """(segundos, origem): 'sua' (corrigida por você) > 'LATAM' (Divine Pride) > 'padrão'."""
        k = chave(nome)
        m = self.meus.get(k)
        if m and m.get("cd"):
            return m["cd"], "sua"
        it = self.itens.get(k)
        if it and self.dp and it.get("id") in self.dp.cds:
            return self.dp.cds[it["id"]], "LATAM"
        if it and it["cd"]:
            return it["cd"], "padrão"
        return None, None

    def existe(self, nome):
        k = chave(nome)
        return k in self.itens or k in self.meus

    def buscar(self, texto, classe=TODAS, limite=300):
        q = chave(texto)
        todos = dict(self.itens)
        for k, m in self.meus.items():
            todos.setdefault(k, {"nome": m["nome"], "cd": None, "classes": []})
        res = []
        for k, it in todos.items():
            if classe and classe != TODAS and classe not in it["classes"] and k not in self.meus:
                continue
            if q and q not in k:
                continue
            res.append((0 if k.startswith(q) else 1, k, it))
        res.sort(key=lambda r: (r[0], r[1]))
        return [r[2] for r in res[:limite]]

    def salvar_meu(self, nome, cd):
        k = chave(nome)
        if not k or re.fullmatch(r"skill \d+", k):
            return
        padrao = self.itens.get(k, {}).get("cd")
        if cd is None or cd == padrao:
            if self.meus.pop(k, None) is None:
                return
        else:
            self.meus[k] = {"nome": nome.strip(), "cd": cd}
        try:
            gravar_json(ARQ_MEUS, self.meus)
        except Exception:
            pass


def _segundos(v):
    """Converte o valor de recarga da API (número ou texto) para segundos."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        x = float(v)
        return x / 1000 if x > 300 else x
    if isinstance(v, str):
        nums = re.findall(r"\d+(?:[.,]\d+)?", v)
        if not nums:
            return None
        x = float(nums[-1].replace(",", "."))
        low = v.lower()
        if "ms" in low:
            x /= 1000
        elif x > 300 and not re.search(r"\d\s*(s|sec|seg)", low):
            x /= 1000
        return x
    if isinstance(v, list) and v:
        return _segundos(v[-1])
    if isinstance(v, dict):
        for k in ("value", "time", "seconds"):
            if k in v:
                return _segundos(v[k])
    return None


def extrair_recarga(d):
    """Recarga no nível máximo a partir da resposta da Divine Pride."""
    melhor = None
    lt = d.get("levelTable") if isinstance(d, dict) else None
    if isinstance(lt, list):
        def nivel(e):
            for k in ("level", "skillLevel", "lv", "Level"):
                if isinstance(e.get(k), (int, float)):
                    return e[k]
            return 0
        linhas = [e for e in lt if isinstance(e, dict)]
        if linhas:
            ult = max(linhas, key=nivel)
            for k, v in ult.items():
                if "cool" in k.lower():
                    melhor = _segundos(v)
                    break
    if melhor is None and isinstance(d, dict):
        melhor = _segundos(d.get("cooldown"))
    return round(melhor, 2) if melhor and melhor > 0 else None


class DivinePride:
    """Busca recarga e ícone de cada skill que você usa (servidor LATAM) e guarda no PC.
    Só pede à API as skills dos seus perfis, uma por vez e com cache, como a API pede."""

    def __init__(self, chave_api):
        self.chave = (chave_api or "").strip()
        self.fila = queue.Queue()
        self.pedidos = queue.Queue()
        self.cds = {}
        PASTA_DP.mkdir(exist_ok=True)
        for arq in PASTA_DP.glob("skill_*.json"):
            try:
                sid = int(arq.stem.split("_")[1])
                cd = extrair_recarga(json.loads(arq.read_text(encoding="utf-8")))
                if cd:
                    self.cds[sid] = cd
            except Exception:
                pass
        self._ultimo = 0.0
        threading.Thread(target=self._trabalhar, daemon=True).start()

    def ativo(self):
        return bool(self.chave)

    def icone(self, sid):
        p = PASTA_DP / f"icone_{sid}.png"
        return p if sid and p.exists() else None

    def pedir(self, sid, motivo):
        if sid and (self.ativo() or (PASTA_DP / f"skill_{sid}.json").exists()):
            self.pedidos.put((int(sid), motivo))

    def _abrir(self, url, json_=True):
        req = urllib.request.Request(url, headers={
            "Accept-Language": "pt", "x-server": "LATAM",
            "User-Agent": "RO-Cooldown-Overlay/1.0 (ferramenta pessoal)"})
        for tentativa in range(3):
            espera = 1.2 - (time.monotonic() - self._ultimo)
            if espera > 0:
                time.sleep(espera)
            self._ultimo = time.monotonic()
            try:
                with urllib.request.urlopen(req, timeout=15) as r:
                    dados = r.read()
                return json.loads(dados.decode("utf-8")) if json_ else dados
            except urllib.error.HTTPError as e:
                if e.code == 429 and tentativa < 2:
                    time.sleep(min(60, int(e.headers.get("Retry-After") or 10)))
                    continue
                if e.code == 401:
                    raise ValueError("chave da API inválida (401)")
                if e.code == 404:
                    raise ValueError("skill não encontrada na Divine Pride (404)")
                raise ValueError(f"erro HTTP {e.code}")
        raise ValueError("limite de pedidos da API; tente mais tarde")

    def _trabalhar(self):
        while True:
            sid, motivo = self.pedidos.get()
            arq = PASTA_DP / f"skill_{sid}.json"
            try:
                if arq.exists() and time.time() - arq.stat().st_mtime < 30 * 86400:
                    dados = json.loads(arq.read_text(encoding="utf-8"))
                else:
                    if not self.ativo():
                        raise ValueError("sem chave da API")
                    url = DP_URL.format(id=sid) + "?apiKey=" + urllib.parse.quote(self.chave)
                    dados = self._abrir(url)
                    arq.write_text(json.dumps(dados, ensure_ascii=False), encoding="utf-8")
                    registrar(f"Divine Pride: skill {sid} recebida: "
                              + json.dumps(dados, ensure_ascii=False)[:2000])
                cd = extrair_recarga(dados)
                if cd:
                    self.cds[sid] = cd
                ico = PASTA_DP / f"icone_{sid}.png"
                url_ico = dados.get("iconUrl") if isinstance(dados, dict) else None
                if url_ico and not ico.exists() and self.ativo():
                    ico.write_bytes(self._abrir(url_ico, json_=False))
                self.fila.put(("ok", sid, cd, motivo, dados.get("name") if isinstance(dados, dict) else None))
            except Exception as e:
                registrar(f"Divine Pride: erro na skill {sid}: {e}")
                self.fila.put(("erro", sid, str(e), motivo, None))


def icone_dp_rgb(caminho):
    """Ícone da Divine Pride (com transparência) sobre fundo escuro, em RGB."""
    im = Image.open(caminho).convert("RGBA")
    fundo = Image.new("RGBA", im.size, (40, 40, 48, 255))
    fundo.alpha_composite(im)
    return fundo.convert("RGB")


class SeletorSkill:
    """Janela de busca: digite parte do nome, escolha e a recarga vem junto."""

    def __init__(self, painel, sk, nova=False):
        self.painel = painel
        self.sk = sk or {}
        self.nova = nova
        sk = self.sk
        b = painel.banco
        self.top = top = tk.Toplevel(painel.win)
        top.title("Escolher skill")
        top.geometry("560x460")
        top.transient(painel.win)
        top.grab_set()

        l1 = ttk.Frame(top)
        l1.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Label(l1, text="Buscar:").pack(side="left")
        self.var_q = tk.StringVar(value=sk.get("nome", "") if b.existe(sk.get("nome", "")) else "")
        ent = ttk.Entry(l1, textvariable=self.var_q, width=28)
        ent.pack(side="left", padx=6)
        ttk.Label(l1, text="Classe:").pack(side="left", padx=(8, 0))
        self.var_cl = tk.StringVar(value=painel.perfil.get("classe", TODAS))
        cb = ttk.Combobox(l1, textvariable=self.var_cl, state="readonly", width=20,
                          values=[TODAS] + b.classes)
        cb.pack(side="left", padx=6)

        cont = ttk.Frame(top)
        cont.pack(fill="both", expand=True, padx=8, pady=4)
        self.tv = ttk.Treeview(cont, columns=("nome", "cd", "classes"), show="headings",
                               selectmode="browse")
        for col, txt, larg in (("nome", "Skill", 200), ("cd", "Recarga", 90),
                               ("classes", "Classes", 220)):
            self.tv.heading(col, text=txt)
            self.tv.column(col, width=larg, anchor="w" if col != "cd" else "center")
        sb = ttk.Scrollbar(cont, orient="vertical", command=self.tv.yview)
        self.tv.configure(yscrollcommand=sb.set)
        self.tv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        rodape = ttk.Frame(top)
        rodape.pack(fill="x", padx=8, pady=(4, 8))
        aviso = ("Recarga padrão sem equipamentos. Se você corrigir o valor depois, "
                 "o programa lembra (aparece como \"sua\").") if b.ok else (
                 "Arquivo banco_skills.json não encontrado na pasta do programa.")
        ttk.Label(rodape, text=aviso, foreground="#555555", wraplength=330).pack(side="left")
        ttk.Button(rodape, text="Usar", command=self.usar).pack(side="right")
        ttk.Button(rodape, text="Cancelar", command=top.destroy).pack(side="right", padx=4)

        self.mapa = {}
        self.var_q.trace_add("write", lambda *_: self.atualizar())
        cb.bind("<<ComboboxSelected>>", lambda _e: self.atualizar())
        self.tv.bind("<Double-1>", lambda _e: self.usar())
        top.bind("<Return>", lambda _e: self.usar())
        top.bind("<Escape>", lambda _e: top.destroy())
        top.bind("<Down>", self._descer)
        self.atualizar()
        ent.focus_set()

    def atualizar(self):
        self.tv.delete(*self.tv.get_children())
        self.mapa.clear()
        for it in self.painel.banco.buscar(self.var_q.get(), self.var_cl.get()):
            cd, origem = self.painel.banco.recarga(it["nome"])
            txt_cd = "—" if cd is None else f"{cd:g} s" + (f" ({origem})" if origem in ("sua", "LATAM") else "")
            classes = ", ".join(it["classes"][:3]) + ("…" if len(it["classes"]) > 3 else "")
            iid = self.tv.insert("", "end", values=(it["nome"], txt_cd, classes))
            self.mapa[iid] = it
        filhos = self.tv.get_children()
        if filhos:
            self.tv.selection_set(filhos[0])

    def _descer(self, _e):
        if self.tv.focus_get() is not self.tv and self.tv.get_children():
            self.tv.focus_set()
            self.tv.focus(self.tv.selection()[0] if self.tv.selection() else self.tv.get_children()[0])

    def usar(self):
        sel = self.tv.selection()
        if not sel:
            return
        it = self.mapa[sel[0]]
        self.top.destroy()
        if self.nova:
            self.painel.adicionar_por_nome(it["nome"])
        else:
            self.painel.aplicar_skill(self.sk, it["nome"])


# =============================================================== perfis

def nome_seguro(nome):
    return re.sub(r'[<>:"/\\|?*]', "_", (nome or "")).strip().strip(".")


class Perfis:
    @staticmethod
    def listar():
        PASTA_PERFIS.mkdir(exist_ok=True)
        return sorted(p.name for p in PASTA_PERFIS.iterdir() if (p / "perfil.json").exists())

    @staticmethod
    def pasta(nome):
        return PASTA_PERFIS / nome

    @staticmethod
    def carregar(nome):
        try:
            dados = json.loads((PASTA_PERFIS / nome / "perfil.json").read_text(encoding="utf-8"))
        except Exception:
            dados = {}
        perfil = mesclar(PERFIL_PADRAO, dados)
        if dados and dados.get("versao", 3) < 4:
            D = perfil["deteccao"]
            D["fps"] = max(D["fps"], 30)
            D["limiar_pronto"] = round(D["limiar_delay"] * 0.3, 3)
            perfil["versao"] = 4
        return perfil

    @staticmethod
    def salvar(nome, perfil):
        pasta = PASTA_PERFIS / nome
        pasta.mkdir(parents=True, exist_ok=True)
        limpo = {k: v for k, v in perfil.items() if k != "skills"}
        limpo["skills"] = [{k: v for k, v in s.items() if not k.startswith("_")}
                           for s in perfil["skills"]]
        gravar_json(pasta / "perfil.json", limpo)

    @staticmethod
    def criar(nome):
        Perfis.salvar(nome, copy.deepcopy(PERFIL_PADRAO))


def migrar_config_antiga():
    """Importa a configuração da versão anterior como perfil 'Padrão'."""
    if Perfis.listar() or not ARQ_ANTIGO.exists():
        return
    try:
        antigo = json.loads(ARQ_ANTIGO.read_text(encoding="utf-8"))
    except Exception:
        return
    nome = "Padrão"
    pasta = Perfis.pasta(nome)
    pasta.mkdir(parents=True, exist_ok=True)
    perfil = copy.deepcopy(PERFIL_PADRAO)
    for s in antigo.get("skills", []):
        src = PASTA_ICONES_ANTIGA / s.get("icone", "")
        if src.is_file():
            shutil.copy2(src, pasta / src.name)
        perfil["skills"].append({k: s.get(k) for k in
                                 ("nome", "x", "y", "w", "h", "icone", "cd", "aprendido")})
    perfil["titulo_janela_jogo"] = antigo.get("titulo_janela_jogo", "Ragnarok")
    L, D = perfil["layout"], perfil["deteccao"]
    L["tamanho"] = antigo.get("tamanho_icone", L["tamanho"])
    L["espaco"] = antigo.get("espaco", L["espaco"])
    L["esconder_quando_pronto"] = antigo.get("esconder_quando_pronto", False)
    for k in D:
        D[k] = antigo.get(k, D[k])
    Perfis.salvar(nome, perfil)


# =============================================================== overlay

class Overlay:
    def __init__(self, root, painel):
        self.root = root
        self.painel = painel
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        root.attributes("-transparentcolor", COR_TRANSPARENTE)
        root.configure(bg=COR_TRANSPARENTE)
        self.canvas = tk.Canvas(root, bg=COR_TRANSPARENTE, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        root.withdraw()

        self.perfil = None
        self.pasta = None
        self.ativo = False
        self.mover = False
        self.preview_ate = 0.0
        self.janela_visivel = False
        self.jogo = Jogo()
        self.geo = None                # (x, y, w, h) do jogo
        self.jogo_ok = False           # overlay pode aparecer?
        self.estado_jogo = "—"
        self.pos = (0, 0)
        self.meu_hwnd = None
        self.fila_busca = queue.Queue()
        self.buscando = False
        self.busca_desde = 0.0
        self.busca_manual = False
        self._recarregar = False
        self.pendentes = set()
        self.sct = None
        self.caixa = None
        self.frames = 0
        self.w = self.h = 10
        self._arrasto = None
        self._avisou_captura = False

        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.canvas.bind("<MouseWheel>", self._roda)
        self.loop()

    @property
    def skills(self):
        return self.perfil["skills"] if self.perfil else []

    @property
    def L(self):
        return self.perfil["layout"]

    # ---- perfil / layout

    def carregar_perfil(self, perfil, pasta):
        self.perfil = perfil
        self.pasta = pasta
        for sk in self.skills:
            sk["_do_site"] = False
            ref = None
            if sk.get("icone"):
                try:
                    ref = Image.open(pasta / sk["icone"]).convert("RGB")
                except Exception:
                    ref = None
            if ref is None and self.painel.dp.icone(sk.get("id")):
                try:
                    ref = icone_dp_rgb(self.painel.dp.icone(sk["id"]))
                    sk["_do_site"] = True        # ainda não achado na tela
                except Exception:
                    ref = None
            if ref is None:
                ref = Image.new("RGB", (max(4, sk.get("w") or 24), max(4, sk.get("h") or 24)),
                                (90, 90, 90))
            sk["_ref_full"] = ref
            sk["_ref"] = miolo(ref)
            if sk.get("x") is None and not sk["_do_site"]:
                pass                                  # sem ícone ainda: nada a procurar
            elif np is not None:
                sk["_ref_g"] = cinza(sk["_ref"])
                sk["_tmpl"] = sk["_ref_g"].astype(np.uint8)
                sk["_margem"] = ((ref.width - sk["_ref"].width) // 2,
                                 (ref.height - sk["_ref"].height) // 2)
            sk.update(_delay=False, _cont=0, _inicio=-99.0, _fim=0.0, _d=0.0,
                      _contando=False, _decidido=True, _ini_cd=0.0, _vis=True,
                      _ncc=1.0, _perdido_desde=None, _sumiu=False, _ult_busca=-99.0)
        self.preparar_imagens()
        self.calcular_caixa()
        self.relayout()

    def preparar_imagens(self):
        T = self.L["tamanho"]
        for sk in self.skills:
            g = sem_cor_chave(sk["_ref_full"].resize((T, T), Image.NEAREST))
            sk["_img"] = ImageTk.PhotoImage(g)
            sk["_img_cd"] = ImageTk.PhotoImage(
                sem_cor_chave(ImageEnhance.Brightness(g).enhance(0.35)))

    def calcular_caixa(self):
        com_pos = [s for s in self.skills if s.get("x") is not None]
        if not com_pos:
            self.caixa = None
            return
        x0 = min(s["x"] for s in com_pos)
        y0 = min(s["y"] for s in com_pos)
        x1 = max(s["x"] + s["w"] for s in com_pos)
        y1 = max(s["y"] + s["h"] for s in com_pos)
        self.caixa = {"left": x0, "top": y0, "width": x1 - x0, "height": y1 - y0}

    def passo(self):
        T, esp = self.L["tamanho"], self.L["espaco"]
        if self.L["orientacao"] == "vertical":
            return 0, T + BARRA_H + 4 + esp
        return T + esp, 0

    def relayout(self):
        T, esp = self.L["tamanho"], self.L["espaco"]
        n = max(1, len(self.skills))
        if self.L["orientacao"] == "vertical":
            w, h = T + 8, n * (T + BARRA_H + 4) + (n - 1) * esp + 8
        else:
            w, h = n * T + (n - 1) * esp + 8, T + BARRA_H + 11
        self.w, self.h = w, h
        if self.L["x"] is None or self.L["y"] is None:
            if self.geo:
                gx, gy, gw, gh = self.geo
                x = gx + (gw - w) // 2
                y = min(gy + gh // 2 + 140, gy + gh - h - 10)
            else:
                sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
                x, y = (sw - w) // 2, sh // 2 + 140
        else:
            dx, dy = self.delta(self.L.get("origem"))
            x, y = self.L["x"] + dx, self.L["y"] + dy
        self.pos = (x, y)
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self.canvas.config(width=w, height=h)

    def mudar_tamanho(self, T):
        T = max(20, min(160, int(T)))
        if T == self.L["tamanho"]:
            return
        self.L["tamanho"] = T
        self.preparar_imagens()
        self.relayout()
        self.painel.salvar_depois()

    def delta(self, ref):
        """Quanto o jogo andou desde a posição de referência."""
        if ref is None or not self.geo:
            return 0, 0
        return self.geo[0] - ref[0], self.geo[1] - ref[1]

    def origem_agora(self):
        titulo = self.perfil["titulo_janela_jogo"].strip() if self.perfil else ""
        if titulo:
            self.jogo.localizar(titulo, time.monotonic())
            g = self.jogo.geometria()
            if g:
                return [g[0], g[1]]
        return None

    def _fixar_origens(self):
        """Perfis antigos: assume que o jogo não se moveu desde a configuração."""
        o = [self.geo[0], self.geo[1]]
        if self.skills and self.perfil.get("origem_calibracao") is None:
            self.perfil["origem_calibracao"] = o
            self.painel.salvar_depois()
        if self.L["x"] is not None and self.L.get("origem") is None:
            self.L["origem"] = o
            self.painel.salvar_depois()

    def centralizar(self):
        self.L["x"] = self.L["y"] = None
        self.L["origem"] = None
        self.relayout()
        self.preview()
        self.painel.salvar_depois()

    # ---- estados da janela

    def iniciar(self):
        if not self.skills:
            return False
        if self.sct is None:
            self.sct = nova_captura()
        self.ativo = True
        self._atualizar_janela()
        self.procurar_todos()
        return True

    # ---- procurar os ícones na tela

    def busca_disponivel(self):
        return np is not None and cv2 is not None

    def procurar_todos(self):
        if self.busca_disponivel():
            for sk in self.skills:
                self.pendentes.add(id(sk))

    def _pedir_busca(self, sk, agora):
        if self.busca_disponivel() and agora - sk["_ult_busca"] > 3.0:
            sk["_ult_busca"] = agora
            self.pendentes.add(id(sk))

    def _disparar_busca(self):
        if self.buscando and time.monotonic() - self.busca_desde > 20:
            registrar("Busca passou de 20 s sem responder; liberando.")
            self.buscando = False
            if self.busca_manual:
                self.busca_manual = False
                self.painel.status("A busca demorou demais. Detalhes em log.txt.")
        if self.buscando or not self.pendentes:
            return
        alvos = []
        for sk in self.skills:
            if id(sk) not in self.pendentes or "_tmpl" not in sk:
                continue
            if sk["_do_site"]:
                full = np.asarray(sk["_ref_full"].convert("L"))
                alvos.append((id(sk), full, None, ESCALAS_DP))
            else:
                alvos.append((id(sk), sk["_tmpl"], sk["_margem"], (1.0,)))
        self.pendentes.clear()
        if not alvos:
            return
        if self.geo:
            gx, gy, gw, gh = self.geo
            regiao = {"left": gx, "top": gy, "width": gw, "height": gh}
        else:
            with nova_captura() as sct:
                regiao = dict(sct.monitors[1])
        self.buscando = True
        self.busca_desde = time.monotonic()
        registrar(f"Busca iniciada: {len(alvos)} ícone(s) na área {regiao}")
        threading.Thread(target=self._buscar, args=(alvos, regiao), daemon=True).start()

    def _buscar(self, alvos, regiao):
        """Roda em segundo plano: procura cada ícone na área do jogo."""
        res = {}
        t0 = time.monotonic()
        try:
            with nova_captura() as sct:
                shot = sct.grab(regiao)
            rgb = Image.frombytes("RGB", shot.size, shot.rgb)
            tela = np.asarray(rgb.convert("L"))
            for chave_sk, tmpl, margem, escalas in alvos:
                melhor = None
                for esc in escalas:
                    if margem is None:            # ícone do site: redimensiona e usa o miolo
                        fh, fw = tmpl.shape
                        fw, fh = max(4, round(fw * esc)), max(4, round(fh * esc))
                        cheio = cv2.resize(tmpl, (fw, fh), interpolation=cv2.INTER_NEAREST)
                        mx, my = max(1, int(fw * 0.15)), max(1, int(fh * 0.15))
                        t = np.ascontiguousarray(cheio[my:fh - my, mx:fw - mx])
                    else:
                        t, (mx, my) = tmpl, margem
                        fh, fw = t.shape[0] + 2 * my, t.shape[1] + 2 * mx
                    if t.shape[0] > tela.shape[0] or t.shape[1] > tela.shape[1]:
                        continue
                    r = cv2.matchTemplate(tela, t, cv2.TM_CCOEFF_NORMED)
                    _, v, _, loc = cv2.minMaxLoc(r)
                    if v == v and (melhor is None or v > melhor[2]):   # ignora NaN
                        melhor = (loc[0] + regiao["left"] - mx, loc[1] + regiao["top"] - my,
                                  v, fw, fh)
                if melhor:
                    if margem is None:            # guarda o recorte real da tela
                        x0, y0 = melhor[0] - regiao["left"], melhor[1] - regiao["top"]
                        melhor += (rgb.crop((x0, y0, x0 + melhor[3], y0 + melhor[4])),)
                    res[chave_sk] = melhor
        except Exception:
            res["_erro"] = traceback.format_exc()
        res["_tempo"] = time.monotonic() - t0
        self.fila_busca.put((res, [a[0] for a in alvos]))

    def _aplicar_buscas(self):
        while True:
            try:
                res, pedidos = self.fila_busca.get_nowait()
            except queue.Empty:
                return
            self.buscando = False
            manual, self.busca_manual = self.busca_manual, False
            if "_erro" in res:
                registrar("Erro na busca:\n" + res["_erro"])
                self.painel.status("Erro ao procurar na tela. Detalhes em log.txt.")
                continue
            ox, oy = self.pos
            dx, dy = self.delta(self.perfil.get("origem_calibracao"))
            achados, moveu, faltam, linhas, novos = 0, [], [], [], []
            for sk in self.skills:
                if id(sk) not in pedidos:
                    continue
                nome = sk.get("nome") or "?"
                r = res.get(id(sk))
                no_overlay = bool(r) and ox <= r[0] < ox + self.w and oy <= r[1] < oy + self.h
                linhas.append(f"  {nome}: " + (f"semelhança {r[2]:.2f} em ({r[0]}, {r[1]})"
                                                   + (" [em cima do overlay, ignorado]" if no_overlay else "")
                                                   if r else "sem resultado"))
                if r and sk["_do_site"]:
                    if r[2] >= LIMIAR_ACHADO_DP and not no_overlay:
                        if self._fixar_achado_do_site(sk, r):
                            achados += 1
                            novos.append(nome)
                        else:
                            faltam.append(nome + " (em delay; espero ela ficar pronta)")
                    else:
                        faltam.append(nome)
                    continue
                if r and r[2] >= LIMIAR_ACHADO and not no_overlay:
                    achados += 1
                    nx, ny = r[0] - dx, r[1] - dy
                    if abs(nx - sk["x"]) > 1 or abs(ny - sk["y"]) > 1:
                        sk["x"], sk["y"] = nx, ny
                        sk.update(_delay=False, _cont=0, _decidido=True)
                        moveu.append(nome)
                    sk["_sumiu"] = False
                    sk["_perdido_desde"] = None
                else:
                    sk["_sumiu"] = True
                    faltam.append(nome)
            registrar(f"Busca concluída em {res.get('_tempo', 0):.2f} s:\n" + "\n".join(linhas))
            if self._recarregar:
                self._recarregar = False
                self.painel.salvar_agora()
                self.carregar_perfil(self.perfil, self.pasta)
                self.painel.montar_lista()
            elif moveu:
                self.calcular_caixa()
                self.painel.salvar_depois()
            if manual or moveu or faltam or novos:
                txt = f"Busca concluída: {achados} de {len(linhas)} ícone(s) encontrados"
                if novos:
                    txt += f"; achei na tela pela primeira vez: {', '.join(novos)}"
                if moveu:
                    txt += f"; mudaram de lugar: {', '.join(moveu)}"
                if faltam:
                    txt += f"; não estão na tela: {', '.join(faltam)}"
                self.painel.status(txt + ".")

    def _fixar_achado_do_site(self, sk, r):
        """Ícone achado pela imagem da Divine Pride: passa a usar o recorte real da tela."""
        x, y, v, fw, fh, recorte = r
        ref_site = cinza(miolo(sk["_ref_full"].resize((fw, fh), Image.NEAREST)))
        if cinza(miolo(recorte)).mean() < 0.6 * ref_site.mean():
            return False                      # parece estar em delay: captura depois
        if self.perfil.get("origem_calibracao") is None and self.geo:
            self.perfil["origem_calibracao"] = [self.geo[0], self.geo[1]]
        dx, dy = self.delta(self.perfil.get("origem_calibracao"))
        arq = f"icone_site_{sk.get('id')}_{int(time.time())}.png"
        recorte.save(self.pasta / arq)
        sk.update(x=x - dx, y=y - dy, w=fw, h=fh, icone=arq)
        self._recarregar = True
        return True

    def parar(self):
        self.ativo = False
        for sk in self.skills:
            sk.update(_delay=False, _cont=0, _fim=0.0, _contando=False, _decidido=True)
        self._atualizar_janela()

    def set_mover(self, ligado):
        self.mover = ligado
        self._atualizar_janela()
        if self.janela_visivel:
            self.aplicar_estilos()

    def preview(self, seg=2.0):
        self.preview_ate = time.monotonic() + seg
        self._atualizar_janela()

    def _atualizar_janela(self):
        deve = bool(self.skills) and ((self.ativo and self.jogo_ok) or self.mover
                                      or time.monotonic() < self.preview_ate)
        if deve and not self.janela_visivel:
            self.root.deiconify()
            self.root.update_idletasks()
            self.janela_visivel = True
            self.aplicar_estilos()
        elif not deve and self.janela_visivel:
            self.root.withdraw()
            self.janela_visivel = False

    def aplicar_estilos(self):
        hwnd = hwnd_de(self.root)
        self.meu_hwnd = hwnd
        base = WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
        if self.mover:
            mudar_estilo(hwnd, base, WS_EX_TRANSPARENT)       # aceita mouse
        else:
            mudar_estilo(hwnd, base | WS_EX_TRANSPARENT)       # clique atravessa
        ok = user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE)
        if not ok and not self._avisou_captura:
            self._avisou_captura = True
            self.painel.status("Aviso: deixe o overlay longe da barra de atalhos.")

    # ---- arrastar / roda do mouse (modo mover)

    def _press(self, e):
        if self.mover:
            self._arrasto = (e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y())

    def _drag(self, e):
        if self._arrasto:
            ax, ay = self._arrasto
            self.root.geometry(f"+{e.x_root - ax}+{e.y_root - ay}")

    def _release(self, _e):
        if self._arrasto:
            self._arrasto = None
            self.L["x"], self.L["y"] = self.root.winfo_x(), self.root.winfo_y()
            self.L["origem"] = [self.geo[0], self.geo[1]] if self.geo else None
            self.painel.salvar_depois()

    def _roda(self, e):
        if self.mover and self.perfil:
            self.mudar_tamanho(self.L["tamanho"] + (4 if e.delta > 0 else -4))
            self.painel.sincronizar_aparencia()

    # ---- detecção

    def atualizar_estado(self, sk, d, agora):
        """Atualiza o estado bruto do ícone: escuro (delay) ou normal."""
        D = self.perfil["deteccao"]
        quer_delay = d > D["limiar_pronto"] if sk["_delay"] else d >= D["limiar_delay"]
        if quer_delay == sk["_delay"]:
            sk["_cont"] = 0
            return
        sk["_cont"] += 1
        precisa = D["frames_entrar"] if quer_delay else D["frames_confirmar"]
        if sk["_cont"] < precisa:
            return
        sk["_cont"] = 0
        sk["_delay"] = quer_delay
        if quer_delay:
            sk["_inicio"] = agora - (precisa - 1) / D["fps"]
            # se já está contando, esse escurecimento é do delay global de outra skill
            sk["_decidido"] = sk["_contando"]
        else:
            sk["_saida"] = agora - (precisa - 1) / D["fps"]

    def processar_cooldowns(self, agora):
        D = self.perfil["deteccao"]
        varias = len(self.skills) >= 2
        for sk in self.skills:
            # 1) Confirma o início de um cooldown
            if sk["_delay"] and not sk["_decidido"]:
                passou = agora - sk["_inicio"]
                sozinho = varias and passou >= JANELA_GRUPO and not any(
                    o is not sk and abs(o["_inicio"] - sk["_inicio"]) <= JANELA_GRUPO
                    for o in self.skills)
                if sozinho or passou >= D["min_mostrar"]:
                    sk["_decidido"] = True
                    sk["_contando"] = True
                    sk["_ini_cd"] = sk["_inicio"]
            # 2) Encerra o cooldown
            if not sk["_contando"]:
                continue
            manual = sk.get("cd")
            if manual:
                # Recarga manual: confia no tempo digitado
                if agora >= sk["_ini_cd"] + manual and not sk["_delay"]:
                    sk["_contando"] = False
                    sk["_fim"] = agora
            elif not sk["_delay"]:
                # Sem recarga manual: acaba quando o ícone volta, e aprende o tempo
                sk["_contando"] = False
                sk["_fim"] = agora
                dur = sk.get("_saida", agora) - sk["_ini_cd"]
                if dur >= 0.2:
                    sk["aprendido"] = round(dur, 2)
                    self.painel.salvar_depois()

    def loop(self):
        try:
            self._tick()
        except Exception:
            registrar("Erro no loop:\n" + traceback.format_exc(), chave_rep="loop")
        fps = self.perfil["deteccao"]["fps"] if self.perfil else 20
        self.root.after(max(10, 1000 // max(1, int(fps))), self.loop)

    def _tick(self):
        agora = time.monotonic()
        if not self.perfil:
            self._atualizar_janela()
            return
        L = self.L
        titulo = self.perfil["titulo_janela_jogo"].strip()

        # 1) Onde está o jogo?
        if titulo:
            self.jogo.localizar(titulo, agora)
            geo = self.jogo.geometria()
            if geo is None:
                self.estado_jogo = "jogo minimizado" if self.jogo.hwnd else "jogo não encontrado"
        else:
            geo = None
            self.estado_jogo = ""
        if geo != self.geo:
            self.geo = geo
            if geo:
                self._fixar_origens()
            self.relayout()

        # 2) O overlay pode aparecer? (jogo aberto e visível embaixo dele)
        if not titulo:
            self.jogo_ok = True
        elif geo is None:
            self.jogo_ok = False
        elif L["esconder_sem_foco"] and not self.jogo.em_foco():
            self.jogo_ok = False
            self.estado_jogo = "jogo sem foco"
        else:
            gx, gy, gw, gh = geo
            cx, cy = self.pos[0] + self.w // 2, self.pos[1] + self.h // 2
            dentro = gx <= cx < gx + gw and gy <= cy < gy + gh
            # Se o overlay está em cima do jogo, só aparece se nada estiver cobrindo o jogo ali
            self.jogo_ok = not dentro or janela_no_ponto(cx, cy) in (self.jogo.hwnd, self.meu_hwnd)
            self.estado_jogo = "" if self.jogo_ok else "jogo coberto"
        self._atualizar_janela()

        # 3) Leitura dos ícones
        if self.ativo and (geo or not titulo):
            for sk in self.skills:
                if sk.get("x") is None and "_tmpl" in sk:
                    self._pedir_busca(sk, agora)
        if self.ativo and self.caixa and (geo or not titulo):
            dx, dy = self.delta(self.perfil.get("origem_calibracao"))
            caixa = dict(self.caixa, left=self.caixa["left"] + dx, top=self.caixa["top"] + dy)
            shot = self.sct.grab(caixa)
            tela = Image.frombytes("RGB", shot.size, shot.rgb)
            for sk in self.skills:
                if sk.get("x") is None:
                    continue
                x, y = sk["x"] - self.caixa["left"], sk["y"] - self.caixa["top"]
                if titulo:
                    px, py = sk["x"] + dx + sk["w"] // 2, sk["y"] + dy + sk["h"] // 2
                    sk["_vis"] = janela_no_ponto(px, py) == self.jogo.hwnd
                    if not sk["_vis"]:
                        continue             # algo cobrindo a barra: congela o estado
                else:
                    sk["_vis"] = True
                atual = miolo(tela.crop((x, y, x + sk["w"], y + sk["h"])))
                sk["_d"] = diferenca(atual, sk["_ref"])
                if np is not None and "_ref_g" in sk:
                    # Escurecido ou cinza continua parecido; outro ícone no lugar não
                    sk["_ncc"] = semelhanca(cinza(atual), sk["_ref_g"])
                    if sk["_ncc"] < LIMIAR_PERDIDO:
                        if sk["_perdido_desde"] is None:
                            sk["_perdido_desde"] = agora
                        elif agora - sk["_perdido_desde"] > 1.2:
                            self._pedir_busca(sk, agora)
                        continue                 # não conta como delay
                    sk["_perdido_desde"] = None
                    sk["_sumiu"] = False
                self.atualizar_estado(sk, sk["_d"], agora)
            self.processar_cooldowns(agora)
        if geo or not titulo:
            self._disparar_busca()
        self._aplicar_buscas()

        self.frames += 1
        if self.janela_visivel and self.frames % 40 == 0:
            self.root.attributes("-topmost", True)
        self.desenhar(agora, self.jogo_ok)

    # ---- desenho

    def desenhar(self, agora, foco):
        c = self.canvas
        c.delete("all")
        if not self.janela_visivel or not self.skills:
            return
        L = self.L
        T = L["tamanho"]
        dx, dy = self.passo()
        edicao = self.mover or agora < self.preview_ate

        if edicao:
            c.create_rectangle(1, 1, self.w - 2, self.h - 2,
                               fill="#202020", outline="#f1c40f", width=2)
        elif not (self.ativo and foco):
            return

        for i, sk in enumerate(self.skills):
            x0, y0 = 4 + i * dx, 4 + i * dy
            if edicao:
                c.create_image(x0, y0, anchor="nw", image=sk["_img"])
                continue

            decorrido = agora - sk["_ini_cd"]
            em_cd = sk["_contando"]
            voltou = sk["_fim"] > 0 and agora - sk["_fim"] < 0.4
            if L["esconder_quando_pronto"] and not em_cd and not voltou:
                continue

            c.create_image(x0, y0, anchor="nw", image=sk["_img_cd"] if em_cd else sk["_img"])
            if voltou:
                c.create_rectangle(x0 + 1, y0 + 1, x0 + T - 1, y0 + T - 1,
                                   outline="#ffffff", width=3)
            else:
                c.create_rectangle(x0, y0, x0 + T, y0 + T, outline="#000000", width=1)
            if not em_cd:
                continue

            fonte = ("Segoe UI", max(8, int(T * 0.34)), "bold")
            cd = sk.get("cd") or sk.get("aprendido")
            if cd:
                resta = cd - decorrido
                if resta <= 0:
                    txt = "…"
                elif resta >= 60:
                    txt = f"{int(resta // 60)}m"
                elif resta >= 10:
                    txt = f"{math.ceil(resta)}"
                else:
                    txt = f"{resta:.1f}"
                cor = "#ff5555" if 0 < resta <= L["aviso_vermelho_s"] else "#ffffff"
                texto_contorno(c, x0 + T / 2, y0 + T / 2, txt, fonte, cor)
                frac = max(0.0, min(1.0, resta / cd))
                yb = y0 + T + 3
                c.create_rectangle(x0, yb, x0 + T, yb + BARRA_H, fill="#222222", outline="")
                c.create_rectangle(x0, yb, x0 + T * frac, yb + BARRA_H,
                                   fill="#f1c40f", outline="")
            else:
                texto_contorno(c, x0 + T / 2, y0 + T / 2, f"{decorrido:.0f}s", fonte, "#bbbbbb")


# =============================================================== seleção de ícones

class Seletor:
    """Tela congelada onde o usuário arrasta retângulos sobre os ícones."""

    def __init__(self, root, tela, mon, ao_terminar):
        self.ao_terminar = ao_terminar
        W, H = mon["width"], mon["height"]
        self.top = top = tk.Toplevel(root)
        top.overrideredirect(True)
        top.attributes("-topmost", True)
        top.geometry(f"{W}x{H}+{mon['left']}+{mon['top']}")
        self.cv = cv = tk.Canvas(top, width=W, height=H, highlightthickness=0, cursor="crosshair")
        cv.pack()
        self.foto = ImageTk.PhotoImage(tela)
        cv.create_image(0, 0, anchor="nw", image=self.foto)
        cv.create_rectangle(0, 0, W, 34, fill="#111111", outline="")
        cv.create_text(W // 2, 17, fill="#ffffff", font=("Segoe UI", 11, "bold"),
                       text="Arraste um retângulo sobre CADA ícone de skill na barra de atalhos"
                            "   |   Botão direito: desfaz   |   Enter: salvar   |   Esc: cancelar")
        for i, (txt, cor, cmd) in enumerate((("Cancelar", "#c0392b", lambda: self._fim(None)),
                                             ("Salvar", "#27ae60", lambda: self._fim(self.regioes)))):
            x1 = W - 10 - i * 100
            tag = f"bt{i}"
            cv.create_rectangle(x1 - 90, 4, x1, 30, fill=cor, outline="", tags=tag)
            cv.create_text(x1 - 45, 17, text=txt, fill="#ffffff",
                           font=("Segoe UI", 10, "bold"), tags=tag)
            cv.tag_bind(tag, "<ButtonRelease-1>", lambda _e, c=cmd: c())
        self.regioes, self.desenhos = [], []
        self.ini = None
        self.ret = None
        cv.bind("<ButtonPress-1>", self._press)
        cv.bind("<B1-Motion>", self._move)
        cv.bind("<ButtonRelease-1>", self._release)
        top.bind("<Button-3>", self._desfazer)
        top.bind("<Return>", lambda _e: self._fim(self.regioes))
        top.bind("<Escape>", lambda _e: self._fim(None))
        top.after(50, top.focus_force)

    def _press(self, e):
        if e.y < 34:                      # barra de instruções / botões
            return
        self.ini = (e.x, e.y)
        self.ret = self.cv.create_rectangle(e.x, e.y, e.x, e.y, outline="#00ff66", width=2)

    def _move(self, e):
        if self.ret:
            self.cv.coords(self.ret, *self.ini, e.x, e.y)

    def _release(self, e):
        if not self.ret:
            return
        x0, x1 = sorted((self.ini[0], e.x))
        y0, y1 = sorted((self.ini[1], e.y))
        if x1 - x0 < 6 or y1 - y0 < 6:
            self.cv.delete(self.ret)
            self.ret = None
            return
        txt = self.cv.create_text(x0, y0 - 10, text=str(len(self.regioes) + 1), anchor="w",
                                  fill="#00ff66", font=("Segoe UI", 10, "bold"))
        self.regioes.append((x0, y0, x1 - x0, y1 - y0))
        self.desenhos.append((self.ret, txt))
        self.ret = None

    def _desfazer(self, _e):
        if self.regioes:
            self.regioes.pop()
            for d in self.desenhos.pop():
                self.cv.delete(d)

    def _fim(self, regioes):
        self.top.destroy()
        self.ao_terminar(regioes)


# =============================================================== painel

class Painel:
    def __init__(self, root):
        self.root = root
        self.app_cfg = ler_json(ARQ_APP, {"ultimo_perfil": None, "iniciar_auto": False})
        migrar_config_antiga()
        if not Perfis.listar():
            Perfis.criar("Meu perfil")

        self.win = tk.Toplevel(root)
        self.win.title(f"{NOME_APP} v{VERSAO}")
        self.win.geometry("820x820")
        self.win.minsize(640, 560)
        self.win.protocol("WM_DELETE_WINDOW", self.sair)

        self.nome = None
        self.perfil = None
        self._carregando = False
        self._salvar_agendado = False
        self._estava_ativo = False
        self._preenchendo = False
        self.banco = Banco()
        self.dp = DivinePride(self.app_cfg.get("dp_chave", ""))
        self.banco.dp = self.dp

        self.overlay = Overlay(root, self)
        self._montar_ui()

        ultimo = self.app_cfg.get("ultimo_perfil")
        lista = Perfis.listar()
        self.trocar_perfil(ultimo if ultimo in lista else lista[0])
        self.win.after(300, self._atualizar_status)
        if self.app_cfg.get("iniciar_auto") and self.perfil["skills"]:
            self.win.after(500, self.iniciar)

    # ---- interface

    def _montar_ui(self):
        w = self.win
        pad = {"padx": 8, "pady": 4}

        # Perfil
        fp = ttk.LabelFrame(w, text="Perfil")
        fp.pack(fill="x", **pad)
        self.var_perfil = tk.StringVar()
        self.cb_perfil = ttk.Combobox(fp, textvariable=self.var_perfil, state="readonly", width=30)
        self.cb_perfil.pack(side="left", padx=6, pady=6)
        self.cb_perfil.bind("<<ComboboxSelected>>",
                            lambda _e: self.trocar_perfil(self.var_perfil.get()))
        for txt, cmd in (("Novo", self.novo_perfil), ("Duplicar", self.duplicar_perfil),
                         ("Renomear", self.renomear_perfil), ("Excluir", self.excluir_perfil)):
            ttk.Button(fp, text=txt, command=cmd).pack(side="left", padx=2)

        # Skills
        fs = ttk.LabelFrame(w, text="Skills")
        fs.pack(fill="both", expand=True, **pad)
        barra = ttk.Frame(fs)
        barra.pack(fill="x", padx=6, pady=(6, 2))
        ttk.Button(barra, text="Marcar ícones na tela",
                   command=lambda: self.marcar_icones(True)).pack(side="left")
        ttk.Button(barra, text="Procurar na tela", command=self.procurar_icones).pack(side="left")
        ttk.Button(barra, text="+ Skill pelo nome",
                   command=lambda: SeletorSkill(self, None, nova=True)).pack(side="left", padx=4)
        ttk.Button(barra, text="Adicionar mais ícones",
                   command=lambda: self.marcar_icones(False)).pack(side="left", padx=4)
        barra2 = ttk.Frame(fs)
        barra2.pack(fill="x", padx=6, pady=(2, 2))
        ttk.Label(barra2, text="Sua classe:").pack(side="left")
        self.var_classe = tk.StringVar(value=TODAS)
        cb_cl = ttk.Combobox(barra2, textvariable=self.var_classe, state="readonly", width=24,
                             values=[TODAS] + self.banco.classes)
        cb_cl.pack(side="left", padx=4)
        cb_cl.bind("<<ComboboxSelected>>", lambda _e: self._on_classe())
        ttk.Label(fs, foreground="#555555",
                  wraplength=760, justify="left",
                  text="Clique em \"Buscar\" para escolher a skill do banco (a recarga vem junto), "
                       "ou digite a recarga (12, 4.5 ou 1:30). Vazio = aprender sozinho."
                  ).pack(anchor="w", padx=8)

        cont = ttk.Frame(fs)
        cont.pack(fill="both", expand=True, padx=6, pady=6)
        self.lista_cv = tk.Canvas(cont, highlightthickness=0, height=200)
        sb = ttk.Scrollbar(cont, orient="vertical", command=self.lista_cv.yview)
        self.lista = ttk.Frame(self.lista_cv)
        self.lista.bind("<Configure>", lambda _e: self.lista_cv.configure(
            scrollregion=self.lista_cv.bbox("all")))
        self.lista_cv.create_window((0, 0), window=self.lista, anchor="nw")
        self.lista_cv.configure(yscrollcommand=sb.set)
        self.lista_cv.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        rolar = lambda e: self.lista_cv.yview_scroll(-1 if e.delta > 0 else 1, "units")
        self.lista_cv.bind("<Enter>", lambda _e: self.lista_cv.bind_all("<MouseWheel>", rolar))
        self.lista_cv.bind("<Leave>", lambda _e: self.lista_cv.unbind_all("<MouseWheel>"))

        # Aparência
        fa = ttk.LabelFrame(w, text="Aparência")
        fa.pack(fill="x", **pad)
        self.var_tam = tk.IntVar()
        self.var_esp = tk.IntVar()
        self.var_ori = tk.StringVar()
        self.var_esconder = tk.BooleanVar()

        l1 = ttk.Frame(fa)
        l1.pack(fill="x", padx=6, pady=2)
        ttk.Label(l1, text="Tamanho").pack(side="left")
        tk.Scale(l1, from_=20, to=160, resolution=2, orient="horizontal", length=180,
                 variable=self.var_tam, command=self._on_tam).pack(side="left", padx=(4, 16))
        ttk.Label(l1, text="Espaço").pack(side="left")
        tk.Scale(l1, from_=0, to=40, orient="horizontal", length=120,
                 variable=self.var_esp, command=self._on_esp).pack(side="left", padx=4)

        l2 = ttk.Frame(fa)
        l2.pack(fill="x", padx=6, pady=2)
        ttk.Label(l2, text="Direção:").pack(side="left")
        for txt, val in (("Horizontal", "horizontal"), ("Vertical", "vertical")):
            ttk.Radiobutton(l2, text=txt, value=val, variable=self.var_ori,
                            command=self._on_ori).pack(side="left", padx=4)
        ttk.Checkbutton(l2, text="Só mostrar quando estiver em delay", variable=self.var_esconder,
                        command=self._on_esconder).pack(side="left", padx=16)
        self.var_sem_foco = tk.BooleanVar()
        l2b = ttk.Frame(fa)
        l2b.pack(fill="x", padx=6, pady=2)
        ttk.Checkbutton(l2b, text="Esconder quando o jogo não estiver em foco "
                                  "(desmarcado: aparece sempre que o jogo estiver visível)",
                        variable=self.var_sem_foco, command=self._on_sem_foco).pack(side="left")

        l3 = ttk.Frame(fa)
        l3.pack(fill="x", padx=6, pady=(2, 6))
        self.bt_mover = ttk.Button(l3, text="Mover / redimensionar", command=self.alternar_mover)
        self.bt_mover.pack(side="left")
        ttk.Button(l3, text="Centralizar", command=lambda: self.overlay.centralizar()).pack(
            side="left", padx=4)
        ttk.Label(l3, foreground="#555555",
                  text="Arraste a caixa amarela; roda do mouse = tamanho."
                  ).pack(side="left", padx=8)

        # Detecção
        fd = ttk.LabelFrame(w, text="Detecção (avançado)")
        fd.pack(fill="x", **pad)
        self.var_min = tk.StringVar()
        self.var_lim = tk.StringVar()
        self.var_titulo = tk.StringVar()
        ttk.Label(fd, text="Delay global da sua build (s)").grid(
            row=0, column=0, sticky="w", padx=6, pady=3)
        ttk.Spinbox(fd, from_=0, to=5, increment=0.1, width=6,
                    textvariable=self.var_min).grid(row=0, column=1, sticky="w")
        ttk.Label(fd, text="Limiar (menor = mais sensível)").grid(
            row=0, column=2, sticky="w", padx=(16, 6))
        ttk.Spinbox(fd, from_=0.03, to=0.5, increment=0.01, width=6,
                    textvariable=self.var_lim).grid(row=0, column=3, sticky="w")
        ttk.Label(fd, text="Título da janela do jogo contém").grid(
            row=1, column=0, sticky="w", padx=6, pady=(3, 6))
        ttk.Entry(fd, textvariable=self.var_titulo, width=20).grid(
            row=1, column=1, columnspan=2, sticky="w", pady=(3, 6))
        self.var_min.trace_add("write", lambda *_: self._on_deteccao())
        self.var_lim.trace_add("write", lambda *_: self._on_deteccao())
        self.var_titulo.trace_add("write", lambda *_: self._on_deteccao())

        # Divine Pride
        fdp = ttk.LabelFrame(w, text="Divine Pride (opcional: recarga do LATAM e ícones)")
        fdp.pack(fill="x", **pad)
        ttk.Label(fdp, text="Chave da API:").pack(side="left", padx=(6, 4), pady=6)
        self.var_dp = tk.StringVar(value=self.app_cfg.get("dp_chave", ""))
        ttk.Entry(fdp, textvariable=self.var_dp, width=34, show="•").pack(side="left")
        ttk.Button(fdp, text="Salvar e testar", command=self.testar_dp).pack(side="left", padx=6)
        self.lbl_dp = ttk.Label(fdp, foreground="#555555",
                                text="Grátis no perfil do divine-pride.net"
                                if not self.dp.ativo() else "Chave salva.")
        self.lbl_dp.pack(side="left", padx=4)

        # Rodapé
        fr = ttk.Frame(w)
        fr.pack(fill="x", padx=8, pady=(4, 2))
        self.bt_iniciar = ttk.Button(fr, text="▶ Iniciar overlay", command=self.alternar_overlay)
        self.bt_iniciar.pack(side="left")
        self.var_auto = tk.BooleanVar(value=bool(self.app_cfg.get("iniciar_auto")))
        ttk.Checkbutton(fr, text="Iniciar automaticamente ao abrir", variable=self.var_auto,
                        command=self._on_auto).pack(side="left", padx=12)
        ttk.Button(fr, text="Abrir pasta de dados (logs)",
                   command=lambda: os.startfile(PASTA)).pack(side="right")
        self.lbl_status = ttk.Label(w, text="", foreground="#555555")
        self.lbl_status.pack(fill="x", padx=10, pady=(0, 8))

    def status(self, txt):
        self.lbl_status.config(text=txt)

    # ---- lista de skills

    def montar_lista(self):
        for wdg in self.lista.winfo_children():
            wdg.destroy()
        for col, t in enumerate(("", "Nome", "", "Recarga (s)", "Aprendido", "Estado", "")):
            ttk.Label(self.lista, text=t, font=("Segoe UI", 9, "bold")).grid(
                row=0, column=col, padx=4, sticky="w")
        skills = self.perfil["skills"]
        if not skills:
            ttk.Label(self.lista, justify="left", text=(
                "Primeiros passos:\n"
                "  1. Abra o Ragnarok em modo janela (ou janela sem bordas).\n"
                "  2. Clique em \"Marcar ícones na tela\" e arraste um quadrado sobre cada skill\n"
                "      da sua barra de atalhos (com as skills prontas, sem delay).\n"
                "  3. Clique em \"Buscar\" em cada linha para escolher o nome da skill.\n"
                "  4. Clique em \"Iniciar overlay\" e jogue!")
                      ).grid(row=1, column=0, columnspan=7, pady=12, padx=6, sticky="w")
            return
        for i, sk in enumerate(skills):
            r = i + 1
            sk["_thumb"] = ImageTk.PhotoImage(sk["_ref_full"].resize((28, 28), Image.NEAREST))
            ttk.Label(self.lista, image=sk["_thumb"]).grid(row=r, column=0, padx=4, pady=2)

            vn = tk.StringVar(value=sk.get("nome") or "")
            ttk.Entry(self.lista, textvariable=vn, width=22).grid(row=r, column=1, padx=(4, 0))
            vn.trace_add("write", lambda *_, s=sk, v=vn: self._on_nome(s, v))
            ttk.Button(self.lista, text="Buscar", width=7,
                       command=lambda s=sk: SeletorSkill(self, s)).grid(row=r, column=2, padx=(2, 4))

            vc = tk.StringVar(value=fmt_tempo(sk.get("cd")))
            ec = tk.Entry(self.lista, textvariable=vc, width=8, justify="center")
            ec.grid(row=r, column=3, padx=4)
            vc.trace_add("write", lambda *_, s=sk, v=vc, e=ec: self._on_cd(s, v, e))
            sk["_vars"] = (vn, vc)

            sk["_lbl_apr"] = ttk.Label(self.lista, text=fmt_aprendido(sk), width=10)
            sk["_lbl_apr"].grid(row=r, column=4, padx=4)
            sk["_lbl_est"] = ttk.Label(self.lista, text="—", width=14)
            sk["_lbl_est"].grid(row=r, column=5, padx=4)

            fb = ttk.Frame(self.lista)
            fb.grid(row=r, column=6, padx=4)
            ttk.Button(fb, text="▲", width=3,
                       command=lambda k=i: self.mover_skill(k, -1)).pack(side="left")
            ttk.Button(fb, text="▼", width=3,
                       command=lambda k=i: self.mover_skill(k, 1)).pack(side="left")
            ttk.Button(fb, text="✕", width=3,
                       command=lambda k=i: self.remover_skill(k)).pack(side="left", padx=(4, 0))

    def _on_nome(self, sk, var):
        sk["nome"] = var.get()
        # Nome digitado igual a uma skill do banco e recarga vazia: preenche sozinho
        if not self._preenchendo and sk.get("cd") is None:
            cd, _ = self.banco.recarga(sk["nome"])
            if cd:
                self._preencher_cd(sk, cd)
        self.salvar_depois()

    def _on_cd(self, sk, var, entry):
        v, ok = ler_tempo(var.get())
        entry.config(bg="white" if ok else "#ffcccc")
        if ok:
            sk["cd"] = v
            if not self._preenchendo:
                self.banco.salvar_meu(sk.get("nome", ""), v)   # lembra para outros perfis
            self.salvar_depois()

    def _preencher_cd(self, sk, cd):
        self._preenchendo = True
        try:
            sk["_vars"][1].set(fmt_tempo(cd))
        finally:
            self._preenchendo = False

    def aplicar_skill(self, sk, nome):
        """Chamado pela janela de busca."""
        self._preenchendo = True
        try:
            sk["_vars"][0].set(nome)
        finally:
            self._preenchendo = False
        sk["id"] = self.banco.id_de(nome)
        cd, _ = self.banco.recarga(nome)
        if cd:
            self._preencher_cd(sk, cd)
        if sk["id"] and self.dp.ativo():
            self.dp.pedir(sk["id"], "cd")
        self.status(f"{nome}: recarga {fmt_tempo(cd) + ' s' if cd else 'não cadastrada (vai aprender sozinho)'}.")

    def adicionar_por_nome(self, nome):
        """Nova skill sem marcar: o ícone vem da Divine Pride e o programa acha na tela."""
        sid = self.banco.id_de(nome)
        cd, _ = self.banco.recarga(nome)
        self.perfil["skills"].append({"nome": nome, "id": sid, "x": None, "y": None,
                                      "w": 24, "h": 24, "icone": None, "cd": cd,
                                      "aprendido": None})
        self.salvar_agora()
        self.overlay.carregar_perfil(self.perfil, Perfis.pasta(self.nome))
        self.montar_lista()
        if not sid:
            self.status(f"{nome}: sem código da skill; use \"Marcar ícones na tela\" para ela.")
        elif not self.dp.ativo() and not self.dp.icone(sid):
            self.status(f"{nome} adicionada. Para achá-la na tela sem marcar, "
                        "coloque sua chave da Divine Pride; ou use \"Adicionar mais ícones\".")
        else:
            self.dp.pedir(sid, "buscar")
            self.status(f"{nome} adicionada. Baixando ícone e procurando na tela…")

    def testar_dp(self):
        self.dp.chave = self.var_dp.get().strip()
        self.app_cfg["dp_chave"] = self.dp.chave
        gravar_json(ARQ_APP, self.app_cfg)
        if not self.dp.ativo():
            self.lbl_dp.config(text="Sem chave: usando só o banco local.")
            return
        (PASTA_DP / "skill_28.json").unlink(missing_ok=True)      # força consulta real
        self.dp.pedir(28, "teste")
        self.lbl_dp.config(text="Testando…")

    def _sid(self, sk):
        if not sk.get("id"):
            sk["id"] = self.banco.id_de(sk.get("nome", ""))
        return sk.get("id")

    def _processar_dp(self):
        while True:
            try:
                tipo, sid, info, motivo, nome_site = self.dp.fila.get_nowait()
            except queue.Empty:
                return
            if motivo == "teste":
                if tipo == "ok":
                    self.lbl_dp.config(text="Conectado ✓ Buscando recargas das suas skills…")
                    for sk in self.perfil["skills"]:
                        if self._sid(sk):
                            self.dp.pedir(sk["id"], "cd")
                else:
                    self.lbl_dp.config(text=f"Erro: {info}")
                continue
            if tipo == "erro":
                self.status(f"Divine Pride: {info}")
                continue
            alvo = [sk for sk in self.perfil["skills"] if self._sid(sk) == sid]
            for sk in alvo:
                # só troca se você não tiver posto um valor seu
                padrao = self.banco.recarga_padrao(sk.get("nome", ""))
                meu = self.banco.meus.get(chave(sk.get("nome", "")))
                if info and not meu and sk.get("cd") in (None, padrao) and "_vars" in sk:
                    self._preencher_cd(sk, info)
            if motivo == "buscar" and alvo:
                self.overlay.carregar_perfil(self.perfil, Perfis.pasta(self.nome))
                self.montar_lista()
                if not self.overlay.ativo:
                    self.iniciar()
                self.overlay.procurar_todos()
                self.overlay.busca_manual = True
            if info and alvo:
                self.status(f"{alvo[0].get('nome')}: recarga LATAM (Divine Pride) = {fmt_tempo(info)} s.")

    def _on_classe(self):
        self.perfil["classe"] = self.var_classe.get()
        self.salvar_depois()

    def mover_skill(self, k, d):
        skills = self.perfil["skills"]
        j = k + d
        if 0 <= j < len(skills):
            skills[k], skills[j] = skills[j], skills[k]
            self.montar_lista()
            self.overlay.preview()
            self.salvar_depois()

    def remover_skill(self, k):
        sk = self.perfil["skills"][k]
        if not messagebox.askyesno("Remover", f"Remover \"{sk.get('nome')}\"?", parent=self.win):
            return
        if sk.get("icone"):
            (Perfis.pasta(self.nome) / sk["icone"]).unlink(missing_ok=True)
        self.perfil["skills"].pop(k)
        self.overlay.carregar_perfil(self.perfil, Perfis.pasta(self.nome))
        self.montar_lista()
        if not self.perfil["skills"]:
            self.parar()
        self.salvar_agora()

    # ---- marcar ícones

    def marcar_icones(self, substituir):
        if substituir and self.perfil["skills"] and not messagebox.askyesno(
                "Marcar ícones", "Isso substitui os ícones deste perfil. Continuar?",
                parent=self.win):
            return
        self._estava_ativo = self.overlay.ativo
        if self.overlay.mover:
            self.alternar_mover()
        self.overlay.parar()
        self.bt_iniciar.config(text="▶ Iniciar overlay")
        self.win.withdraw()

        aviso = tk.Toplevel(self.root)
        aviso.overrideredirect(True)
        aviso.attributes("-topmost", True)
        lbl = tk.Label(aviso, font=("Segoe UI", 14, "bold"), bg="#111111", fg="#ffffff",
                       padx=24, pady=14, justify="center")
        lbl.pack()
        aviso.geometry(f"+{aviso.winfo_screenwidth() // 2 - 300}+40")

        def contar(n):
            if n > 0:
                lbl.config(text="Clique no jogo e deixe as skills PRONTAS (sem delay)\n"
                                f"Capturando a tela em {n}...")
                aviso.after(1000, contar, n - 1)
            else:
                aviso.destroy()
                self.root.after(250, lambda: self._capturar(substituir))
        contar(5)

    def _capturar(self, substituir):
        with nova_captura() as sct:
            mon = dict(sct.monitors[1])
            shot = sct.grab(mon)
        tela = Image.frombytes("RGB", shot.size, shot.rgb)
        Seletor(self.root, tela, mon,
                lambda regs: self._fim_selecao(regs, tela, mon, substituir))

    def _fim_selecao(self, regioes, tela, mon, substituir):
        if regioes:
            pasta = Perfis.pasta(self.nome)
            pasta.mkdir(parents=True, exist_ok=True)
            skills = self.perfil["skills"]
            if substituir:
                for sk in skills:
                    if sk.get("icone"):
                        (pasta / sk["icone"]).unlink(missing_ok=True)
                skills.clear()
            origem = self.overlay.origem_agora()
            ref = self.perfil.get("origem_calibracao")
            if not skills or ref is None or origem is None:
                self.perfil["origem_calibracao"] = origem
                ox = oy = 0
            else:   # converte para o mesmo referencial dos ícones já marcados
                ox, oy = origem[0] - ref[0], origem[1] - ref[1]
            stamp = int(time.time())
            for i, (x, y, w, h) in enumerate(regioes, 1):
                arq = f"icone_{stamp}_{i}.png"
                tela.crop((x, y, x + w, y + h)).save(pasta / arq)
                skills.append({"nome": f"Skill {len(skills) + 1}",
                               "x": x + mon["left"] - ox, "y": y + mon["top"] - oy, "w": w, "h": h,
                               "icone": arq, "cd": None, "aprendido": None})
            self.salvar_agora()
            self.overlay.carregar_perfil(self.perfil, pasta)
            self.montar_lista()
            self.status(f"{len(regioes)} ícone(s) marcado(s). Dê nomes e recargas na lista.")
        self.win.deiconify()
        self.win.lift()
        if self._estava_ativo:
            self.iniciar()

    # ---- perfis

    def trocar_perfil(self, nome):
        if self.perfil is not None and self.nome:
            Perfis.salvar(self.nome, self.perfil)
        self.nome = nome
        self.perfil = Perfis.carregar(nome)
        self.app_cfg["ultimo_perfil"] = nome
        gravar_json(ARQ_APP, self.app_cfg)
        self.cb_perfil["values"] = Perfis.listar()
        self.var_perfil.set(nome)
        self.overlay.carregar_perfil(self.perfil, Perfis.pasta(nome))
        self.sincronizar_aparencia()
        self.sincronizar_deteccao()
        classe = self.perfil.get("classe", TODAS)
        self.var_classe.set(classe if classe in self.banco.classes else TODAS)
        self.montar_lista()
        if self.overlay.ativo and not self.perfil["skills"]:
            self.parar()
        self.status(f"Perfil \"{nome}\" carregado.")

    def _pedir_nome(self, titulo, inicial=""):
        nome = simpledialog.askstring(titulo, "Nome do perfil (ex.: nome do personagem):",
                                      initialvalue=inicial, parent=self.win)
        nome = nome_seguro(nome)
        if not nome:
            return None
        if nome in Perfis.listar():
            messagebox.showerror(titulo, "Já existe um perfil com esse nome.", parent=self.win)
            return None
        return nome

    def novo_perfil(self):
        nome = self._pedir_nome("Novo perfil")
        if nome:
            Perfis.criar(nome)
            self.trocar_perfil(nome)

    def duplicar_perfil(self):
        nome = self._pedir_nome("Duplicar perfil", f"{self.nome} (cópia)")
        if nome:
            self.salvar_agora()
            shutil.copytree(Perfis.pasta(self.nome), Perfis.pasta(nome))
            self.trocar_perfil(nome)

    def renomear_perfil(self):
        nome = self._pedir_nome("Renomear perfil", self.nome)
        if nome:
            self.salvar_agora()
            Perfis.pasta(self.nome).rename(Perfis.pasta(nome))
            self.perfil = None
            self.trocar_perfil(nome)

    def excluir_perfil(self):
        if not messagebox.askyesno("Excluir perfil",
                                   f"Excluir o perfil \"{self.nome}\" e seus ícones?",
                                   parent=self.win):
            return
        shutil.rmtree(Perfis.pasta(self.nome), ignore_errors=True)
        self.perfil = None
        self.nome = None
        if not Perfis.listar():
            Perfis.criar("Meu perfil")
        self.trocar_perfil(Perfis.listar()[0])

    # ---- aparência / detecção

    def sincronizar_aparencia(self):
        self._carregando = True
        L = self.perfil["layout"]
        self.var_tam.set(L["tamanho"])
        self.var_esp.set(L["espaco"])
        self.var_ori.set(L["orientacao"])
        self.var_esconder.set(bool(L["esconder_quando_pronto"]))
        self.var_sem_foco.set(bool(L["esconder_sem_foco"]))
        self.root.after_idle(self._fim_carregando)

    def sincronizar_deteccao(self):
        self._carregando = True
        D = self.perfil["deteccao"]
        self.var_min.set(f"{D['min_mostrar']:g}")
        self.var_lim.set(f"{D['limiar_delay']:g}")
        self.var_titulo.set(self.perfil["titulo_janela_jogo"])
        self.root.after_idle(self._fim_carregando)

    def _fim_carregando(self):
        self._carregando = False

    def _on_tam(self, val):
        if self._carregando:
            return
        self.overlay.mudar_tamanho(int(float(val)))
        self.overlay.preview()

    def _on_esp(self, val):
        if self._carregando:
            return
        self.perfil["layout"]["espaco"] = int(float(val))
        self.overlay.relayout()
        self.overlay.preview()
        self.salvar_depois()

    def _on_ori(self):
        self.perfil["layout"]["orientacao"] = self.var_ori.get()
        self.overlay.relayout()
        self.overlay.preview()
        self.salvar_depois()

    def _on_sem_foco(self):
        self.perfil["layout"]["esconder_sem_foco"] = bool(self.var_sem_foco.get())
        self.salvar_depois()

    def _on_esconder(self):
        self.perfil["layout"]["esconder_quando_pronto"] = bool(self.var_esconder.get())
        self.salvar_depois()

    def _on_deteccao(self):
        if self._carregando or not self.perfil:
            return
        D = self.perfil["deteccao"]
        try:
            D["min_mostrar"] = max(0.0, float(self.var_min.get().replace(",", ".")))
        except ValueError:
            pass
        try:
            lim = float(self.var_lim.get().replace(",", "."))
            if 0.01 <= lim <= 1:
                D["limiar_delay"] = lim
                D["limiar_pronto"] = round(lim * 0.3, 3)
        except ValueError:
            pass
        self.perfil["titulo_janela_jogo"] = self.var_titulo.get()
        self.salvar_depois()

    def alternar_mover(self):
        ligar = not self.overlay.mover
        self.overlay.set_mover(ligar)
        self.bt_mover.config(text="✔ Concluir posição" if ligar else "Mover / redimensionar")
        if not ligar:
            self.salvar_depois()

    # ---- overlay

    def alternar_overlay(self):
        if self.overlay.ativo:
            self.parar()
        else:
            self.iniciar()

    def procurar_icones(self):
        if not self.overlay.busca_disponivel():
            messagebox.showinfo("Procurar na tela",
                                "Para procurar os ícones sozinho, instale os pacotes:\n\n"
                                "pip install numpy opencv-python\n\n"
                                "(o iniciar.bat já faz isso).", parent=self.win)
            return
        if not self.perfil["skills"]:
            self.status("Marque os ícones primeiro em \"Marcar ícones na tela\".")
            return
        titulo = self.perfil["titulo_janela_jogo"].strip()
        if titulo and self.overlay.origem_agora() is None:
            self.status(f"Não encontrei a janela do jogo (título contendo \"{titulo}\"). "
                        "Abra o jogo, não deixe minimizado e confira o título em Detecção.")
            registrar(f"Procurar: janela do jogo não encontrada (título '{titulo}').")
            return
        if not self.overlay.ativo:
            self.iniciar()
        self.overlay.procurar_todos()
        self.overlay.busca_manual = True
        self.status("Procurando os ícones na tela do jogo…")

    def iniciar(self):
        if not self.perfil["skills"]:
            messagebox.showinfo("RO Cooldown Overlay",
                                'Marque os ícones primeiro em "Marcar ícones na tela".',
                                parent=self.win)
            return
        if self.overlay.iniciar():
            self.bt_iniciar.config(text="■ Parar overlay")
            self.status("Overlay rodando. Pode minimizar esta janela.")

    def parar(self):
        self.overlay.parar()
        self.bt_iniciar.config(text="▶ Iniciar overlay")
        self.status("Overlay parado.")

    def _on_auto(self):
        self.app_cfg["iniciar_auto"] = bool(self.var_auto.get())
        gravar_json(ARQ_APP, self.app_cfg)

    def _atualizar_status(self):
        try:
            for sk in self.overlay.skills:
                le = sk.get("_lbl_est")
                if le is None or not le.winfo_exists():
                    continue
                if not self.overlay.ativo:
                    t = "parado"
                elif self.overlay.geo is None and self.overlay.estado_jogo:
                    t = self.overlay.estado_jogo
                elif not sk.get("_vis", True):
                    t = "barra coberta"
                elif sk.get("x") is None:
                    t = "procurando na tela…" if "_tmpl" in sk else "sem ícone"
                elif sk.get("_sumiu"):
                    t = "não está na tela"
                elif sk.get("_perdido_desde") is not None:
                    t = "procurando…"
                else:
                    t = f"{'DELAY' if sk['_delay'] else 'pronta'} ({sk['_d']:.2f})"
                    if sk.get("_contando"):
                        t += " ⏱"
                le.config(text=t)
                sk["_lbl_apr"].config(text=fmt_aprendido(sk))
        except tk.TclError:
            pass
        try:
            self._processar_dp()
        except Exception:
            registrar("Erro ao aplicar dados da Divine Pride:\n" + traceback.format_exc(),
                      chave_rep="dp")
        self.win.after(250, self._atualizar_status)

    # ---- salvar / sair

    def salvar_depois(self):
        if not self._salvar_agendado:
            self._salvar_agendado = True
            self.win.after(800, self.salvar_agora)

    def salvar_agora(self):
        self._salvar_agendado = False
        if self.perfil is not None and self.nome:
            Perfis.salvar(self.nome, self.perfil)

    def sair(self):
        try:
            self.salvar_agora()
            gravar_json(ARQ_APP, self.app_cfg)
        finally:
            self.root.destroy()


# =============================================================== início

def ja_aberto():
    """Evita abrir dois overlays ao mesmo tempo (duplo clique repetido)."""
    try:
        k32 = ctypes.windll.kernel32
        k32.CreateMutexW.restype = wintypes.HANDLE
        ja_aberto._mutex = k32.CreateMutexW(None, False, "RO_Cooldown_Overlay_instancia")
        return k32.GetLastError() == 183          # ERROR_ALREADY_EXISTS
    except Exception:
        return False


def main():
    if ja_aberto():
        r = tk.Tk()
        r.withdraw()
        messagebox.showinfo(NOME_APP, "O programa já está aberto.\n"
                            "Procure a janela dele na barra de tarefas.")
        return
    dpi_aware()
    root = tk.Tk()
    registrar(f"{NOME_APP} v{VERSAO} iniciado (dados em {PASTA})")

    def erro(exc, val, tb):
        texto = "".join(traceback.format_exception(exc, val, tb))
        (PASTA / "erro.log").write_text(texto, encoding="utf-8")
        messagebox.showerror(NOME_APP, f"Ocorreu um erro:\n{val}\n\n"
                             "Os detalhes foram salvos em erro.log "
                             "(botão \"Abrir pasta de dados\").")

    root.report_callback_exception = erro
    try:
        Painel(root)
    except Exception:
        (PASTA / "erro.log").write_text(traceback.format_exc(), encoding="utf-8")
        raise
    root.mainloop()


if __name__ == "__main__":
    main()
